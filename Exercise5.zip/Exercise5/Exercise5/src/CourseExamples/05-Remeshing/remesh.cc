//== INCLUDES =================================================================

#include <OpenMesh/Core/IO/MeshIO.hh>
#include <OpenMesh/Core/Mesh/Types/TriMesh_ArrayKernelT.hh>
#include <iostream>
#include <set>
//#include <unistd.h> //might be needed for unix (gcc)
#include <float.h>


//== IMPLEMENTATION ===========================================================


typedef OpenMesh::TriMesh_ArrayKernelT<>        Mesh;
Mesh                                            mesh;
OpenMesh::VPropHandleT<Mesh::Point>             update;


//-----------------------------------------------------------------------------


void  split_long_edges(float _long);
void  collapse_short_edges(float _short);
void  equalize_valences();
void  tangential_relaxation();


//-----------------------------------------------------------------------------


int main(int argc, char **argv)
{
	if (argc < 4) 
	{
		std::cerr << "Usage: \n" 
			<< argv[0] << " <edge-length>  <input_mesh>  <output_mesh>\n\n";
		exit(1);
	}
	float target_length = (float)atof(argv[1]);
	float low  = 4.0f/5.0f * target_length;
	float high = 4.0f/3.0f * target_length;


	// add required properties
	mesh.request_vertex_status();
	mesh.request_vertex_normals();
	mesh.request_edge_status();
	mesh.request_face_status();
	mesh.request_face_normals();
	mesh.add_property(update);


	// read mesh
	OpenMesh::IO::read_mesh(mesh, argv[2]);
	std::cout << "#vertices: " << mesh.n_vertices() << std::endl;
	mesh.update_normals();


	// main remeshing loop
	for (int i=0; i<5; ++i)
	{
		split_long_edges(high);
		collapse_short_edges(low);
		equalize_valences();
		tangential_relaxation();
	}


	// write mesh
	OpenMesh::IO::write_mesh(mesh, argv[3]);
}


//-----------------------------------------------------------------------------


void  split_long_edges(float _long)
{
	Mesh::EIter     e_it, e_end;
	Mesh::VHandle   v0, v1, vh;
	Mesh::EHandle   eh, e0, e1;
	Mesh::FHandle   f0, f1, f2, f3;
	bool            finished;
	int             i;



	for (finished=false, i=0; !finished && i<100; ++i)
	{
		finished = true;

		for (e_it=mesh.edges_begin(), e_end=mesh.edges_end(); e_it!=e_end; ++e_it)
		{

			// Exercise 6.1 ----------------------------------------------
			// INSERT CODE:
			// If the edge is longer than _long
			//  1) add the midpoint to the mesh
			//  2) set the interpolated normal to the vertex
			//  3) split the edge with this vertex (use openMesh function split)
			// Leave the loop running until no splits are done (use the finished variable)
			// -----------------------------------------------------------

		}
	}
}


//-----------------------------------------------------------------------------


void  collapse_short_edges(float _short)
{
	Mesh::EIter     e_it, e_end;
	Mesh::CVVIter   vv_it;
	Mesh::VHandle   v0, v1;
	Mesh::HHandle   h0, h1, h01, h10;
	bool            finished, b0, b1;
	int             i;
	bool            hcol01, hcol10;

	for (finished=false, i=0; !finished && i<100; ++i)
	{
		finished = true;

		for (e_it=mesh.edges_begin(), e_end=mesh.edges_end(); e_it!=e_end; ++e_it)
		{
			if (!mesh.status(e_it).deleted()) // might already be deleted
			{

				// Exercise 6.2 ----------------------------------------------
				// INSERT CODE:
				// If the edge is shorter than _short
				//  1) Check if halfedge connects a boundary vertex with a non-boundary vertex. If so, don't collapse. Otherwise
				//  2) Check if halfedges collapsible
				//  3) Select the halfedge to be collapsed if at least one halfedge can be collapsed
				//  4) Collapse the halfedge
				// Leave the loop running until no collapse has been done (use the finished variable)
				// -----------------------------------------------------------

			}
		}
	}

	mesh.garbage_collection();

	if (i==100) std::cerr << "collapse break\n";
}


//-----------------------------------------------------------------------------


void  equalize_valences()
{
	Mesh::EIter     e_it, e_end;
	Mesh::VHandle   v0, v1, v2, v3;
	Mesh::HHandle   hh;
	int             val0, val1, val2, val3;
	int             val_opt0, val_opt1, val_opt2, val_opt3;
	int             ve0, ve1, ve2, ve3, ve_before, ve_after;
	bool            finished;
	int             i;




	// flip all edges
	for (finished=false, i=0; !finished && i<100; ++i)
	{
		finished = true;

		for (e_it=mesh.edges_begin(), e_end=mesh.edges_end(); e_it!=e_end; ++e_it)
		{
			if (!mesh.is_boundary(e_it))
			{

				// Exercise 6.3 ----------------------------------------------
				// INSERT CODE:
				//  1) Extract valences of the four vertices involved to an eventual flip.
				//  2) Compute the sum of the squared valence deviances before flip
				//  3) Compute the sum of the squared valence deviances after and eventual flip
				//  4) If valence deviance is decreased and flip is possible, flip the vertex
				// Leave the loop running until no collapse has been done (use the finished variable)
				// -----------------------------------------------------------

			}
		}
	}

	if (i==100) std::cerr << "flip break\n";
}


//-----------------------------------------------------------------------------


void  tangential_relaxation()
{
	Mesh::VIter     v_it, v_end(mesh.vertices_end());
	Mesh::CVVIter   vv_it;
	Mesh::Scalar    valence;
	Mesh::Point     u, n;


	// smooth
	for (int iters=0; iters<10; ++iters)
	{
		for (v_it=mesh.vertices_begin(); v_it!=v_end; ++v_it)
		{
			if (!mesh.is_boundary(v_it))
			{
				// Exercise 6.4 ----------------------------------------------
				// INSERT CODE:
				//  1) Compute uniform laplacian approximation vector
				//  2) Compute the tangential component of the laplacian vector
				//  3) Store smoothed vertex location in the update vertex property.
				//     (you don't have to use 1/2 attenuation in this case, it's fine without attenuation)
				// -----------------------------------------------------------

			}
		}

		for (v_it=mesh.vertices_begin(); v_it!=v_end; ++v_it)
			if (!mesh.is_boundary(v_it))
				mesh.point(v_it) = mesh.property(update, v_it);
	}
}


//-----------------------------------------------------------------------------
