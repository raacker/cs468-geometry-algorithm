// -*- c++ -*- (enables emacs c++ mode)
//========================================================================
//
// Library : Generic Matrix Methods  (gmm)
// File    : gmm.h : generic algorithms on linear algebra
//           
// Date    : October 13, 2002.
// Author  : Yves Renard <Yves.Renard@insa-toulouse.fr>
//
//========================================================================
//
// Copyright (C) 2002-2005 Yves Renard
//
// This file is a part of GETFEM++
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; version 2 of the License.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software Foundation,
// Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
//
//========================================================================

/**@file gmm.h
   @brief Include common gmm files.
*/
#ifndef GMM_H__
#define GMM_H__

#include <gmm_kernel.h>
#include <gmm_dense_lu.h>
#include <gmm_dense_qr.h>

#include <gmm_iter_solvers.h>
#include <gmm_condition_number.h>
#include <gmm_inoutput.h>

#include <gmm_lapack_interface.h>
#include <gmm_superlu_interface.h>


#include <gmm_domain_decomp.h>

#endif //  GMM_H__
